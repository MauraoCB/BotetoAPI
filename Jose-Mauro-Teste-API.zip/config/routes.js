const express = require('express')
const routes = express.Router()

    routes.get('/boleto/:linhaDigitavel', (req, res) => {
        let linhaDigitavel = req.params.linhaDigitavel
        let dv = linhaDigitavel.substr(9, 1)

        if(!isNumeric(linhaDigitavel)){
            res.status = 400
            return res.json({'status': 400, message: 'A linha digitável deve conter somente números'})
        }       

        //Calculando DV do bloco 1
         if(CalcularBlocoDV(linhaDigitavel.substr(0, 9)) != dv)
        {
            res.status = 400
            return res.json({'status': 400, message: 'DV inválido no bloco 1'})
        }

          //Calculando DV do bloco 2
          dv = linhaDigitavel.substr(20, 1)
          if(CalcularBlocoDV(linhaDigitavel.substr(10, 10)) != dv)
          {
              res.status = 400
              return res.json({'status': 400, message: 'DV inválido no bloco 2'})
          }

            //Calculando DV do bloco 3
           dv = linhaDigitavel.substr(31, 1)
        if(CalcularBlocoDV(linhaDigitavel.substr(21, 10)) != dv)
        {
            res.status = 400
            return res.json({'status': 400, message: 'DV inválido no bloco 3'})
        }

        let fatorVencimento = parseInt(linhaDigitavel.substr(33,4))

        let expirationDate = new Date(1997, 10, 97);
        expirationDate.setDate(expirationDate.getDate() + fatorVencimento);

        let barCode = linhaDigitavel.substr(0,4) + linhaDigitavel.substr(32,1) +
                      fatorVencimento + linhaDigitavel.substr(37,10) + linhaDigitavel.substr(13,17) 
                      
         let amount = parseFloat(linhaDigitavel.substr(37,10)) / 100

        let retorno = [{
            'barCode': barCode,
            'amount': amount.toFixed(2),
            'expirationDate': expirationDate.toISOString().split('T')[0]
            }]

    return res.json(retorno)

})

function CalcularBlocoDV(bloco){
    let soma = 0
    let fator = 1
    for(let i = bloco.length - 1; i >= 0; i--)   
    {
        fator = (fator == 1) ? 2 : 1
        let produto = parseInt(bloco.substr(i,1)) * fator

        if(produto > 9){
            produto = parseInt(produto.toString().substr(0,1)) + parseInt(produto.toString().substr(1,1))
        }

        soma += produto
    }  

    let resto = soma % 10
    let dv = 10 - resto

    if(resto == 10){
        dv = 0
    }

    return  dv
}    

function isNumeric (value){
    for(var i = 0; i< value.length; i++)
    {
        if("0123456789".indexOf(value.substr(i,1)) < 0){
            return false
        }
    }
    return true
}

function CalcularTituloDV(linhaDigitavel){

    return  '0'
}  

module.exports = routes